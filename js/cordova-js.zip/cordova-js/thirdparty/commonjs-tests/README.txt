The test cases contained in this directory were obtained from the
commonjs project at GitHub:

   https://github.com/commonjs/commonjs

Specifically, the directories in the 'tests' subdirectory.

See the file test/commonjs/README.txt off the root directory of this
project for more information.